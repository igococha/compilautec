#include "imp_typechecker.hh"

ImpTypeChecker::ImpTypeChecker() {}

void ImpTypeChecker::typecheck(Program* p) {
  env.clear();
  p->accept(this);
  return;
}

void ImpTypeChecker::visit(Program* p) {
  p->body->accept(this);
  return;
}

void ImpTypeChecker::visit(Body* b) {
  env.add_level();
  b->var_decs->accept(this);
  b->slist->accept(this);
  env.remove_level();  
  return;
}


void ImpTypeChecker::visit(VarDecList* decs) {
  cout << "--start decs---" << endl;
  list<VarDec*>::iterator it;
  for (it = decs->vdlist.begin(); it != decs->vdlist.end(); ++it) {
    (*it)->accept(this);
  }
  cout << "--end decs---" << endl;
  return;
}

void ImpTypeChecker::visit(VarDec* vd) {
  /*
  string type = vd->type;
  if (type.compare("int")!=0 && type.compare("bool")!=0) {
    cout << "Tipo invalido: " << type << endl;
    exit(0);
  }
  list<string>::iterator it;
  for (it = vd->vars.begin(); it != vd->vars.end(); ++it) {
    env.add_var(*it, type);
    cout << "vardec " << vd->type << " " << *it << endl;
  }   
  */
  return;
}

void ImpTypeChecker::visit(StatementList* s) {
  list<Stm*>::iterator it;
  for (it = s->slist.begin(); it != s->slist.end(); ++it) {
    (*it)->accept(this);
  }
  return;
}

void ImpTypeChecker::visit(AssignStatement* s) {
  /*
  string type = s->rhs->accept(this);
  if (!env.check(s->id)) {
    cout << "Variable " << s->id << " undefined" << endl;
    exit(0);
  }
  string var_type = env.lookup(s->id);  
  if (type.compare(var_type)!=0) {
    cout << "Tipo incorrecto en Assign a " << s->id << ": " << var_type << " <--> " << type << endl;
  }
  */
  return;
}

void ImpTypeChecker::visit(PrintStatement* s) {
  s->e->accept(this);
  return;
}

void ImpTypeChecker::visit(IfStatement* s) {
  s->cond->accept(this);
  s->tbody->accept(this);
  if (s->fbody != NULL)
    s->fbody->accept(this);
  return;
}

void ImpTypeChecker::visit(WhileStatement* s) {
  s->cond->accept(this);
  s->body->accept(this);
 return;
}

ImpType ImpTypeChecker::visit(BinaryExp* e) {
  /*
  string t1 = e->left->accept(this);
  string t2 = e->right->accept(this);
  if (t1.compare("int")!=0  || t2.compare("int")!=0) {
    cout << "Tipos en BinExp deben de ser int" << endl;
    exit(0);
  }
  string result;
  switch(e->op) {
  case PLUS: 
  case MINUS:
  case MULT:
  case DIV:
  case EXP:
    result = "int";
    break;
  case LT: 
  case LTEQ:
  case EQ:
    result = "bool";
    break;
  }
  */
  ImpType result;
  result.set_basic_type("void");
  return result;
}

ImpType ImpTypeChecker::visit(NumberExp* e) {
  //return "int";
  ImpType result;
  result.set_basic_type("void");
  return result;
}

ImpType ImpTypeChecker::visit(IdExp* e) {
  if (env.check(e->id))
    return env.lookup(e->id);
  else {
    cout << "Variable indefinida: " << e->id << endl;
    exit(0);
  }
}

ImpType ImpTypeChecker::visit(ParenthExp* ep) {
  return ep->e->accept(this);
}

ImpType ImpTypeChecker::visit(CondExp* e) {
  /*
  if (e->cond->accept(this).compare("bool")!=0) {
    cout << "Tipo en ifexp debe de ser bool" << endl;
    exit(0);
  }
  */
  ImpType ttype =  e->etrue->accept(this);
  /*
  if (ttype.compare(e->efalse->accept(this)) != 0) {
    cout << "Tipos en ifexp deben de ser iguales" << endl;
    exit(0);
  }
  */
  return ttype;
}
