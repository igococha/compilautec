#include "imp_codegen.hh"

void ImpCodeGen::codegen(Program* p, string outfname) {
  p->accept(this);
  ofstream outfile;
  outfile.open(outfname);
  outfile << code.str();
  outfile.close();
  return;
}

int ImpCodeGen::visit(Program* p) {
  p->body->accept(this);
  return 0;
}

int ImpCodeGen::visit(Body * b) {
  b->var_decs->accept(this);
  b->slist->accept(this);
  return 0;
}

int ImpCodeGen::visit(VarDecList* s) {
  list<VarDec*>::iterator it;
  for (it = s->vdlist.begin(); it != s->vdlist.end(); ++it) {
    (*it)->accept(this);
    code << endl;
  }  
  return 0;
}
			  
int ImpCodeGen::visit(VarDec* vd) {
  code << vd->type << " ";
  list<string>::iterator it;
  for (it = vd->vars.begin(); it != vd->vars.end(); ++it){
    code << *it << " ";
  }
  return 0;
}

int ImpCodeGen::visit(StatementList* s) {
  list<Stm*>::iterator it;
  for (it = s->slist.begin(); it != s->slist.end(); ++it) {
    (*it)->accept(this);
  }
  return 0;
}

int ImpCodeGen::visit(AssignStatement* s) {
  code << "assign-stm" << endl;
  //code << s->id << " = ";
  //s->rhs->accept(this);
  return 0;
}

int ImpCodeGen::visit(PrintStatement* s) {
  code << "print-statement" << endl;;
  //s->e->accept(this);
  //code << ")";
  return 0;
}

int ImpCodeGen::visit(IfStatement* s) {
  code << "if-statement" << endl;
  /*
  code << "if (";
  s->cond->accept(this);
  code << ") then" << endl;;
  s->tbody->accept(this);
  if (s->fbody!=NULL) {
    code << "else" << endl;
    s->fbody->accept(this);
  }
  code << "endif";
  */
  return 0;
}

int ImpCodeGen::visit(WhileStatement* s) {
  code << "while-stm" << endl;
  /*
  code << "while (";
  s->cond->accept(this);
  code << ") do" << endl;;
  s->body->accept(this);
  code << "endwhile";
  */
  return 0;
}

int ImpCodeGen::visit(BinaryExp* e) {
  /*
  e->left->accept(this);
  code << ' ' << Exp::binopToString(e->op) << ' ';
  e->right->accept(this);
  */
  return 0;
}

int ImpCodeGen::visit(NumberExp* e) {
  // code << e->value;
  return 0;
}

int ImpCodeGen::visit(IdExp* e) {
  //code << e->id << endl;;
  return 0;
}

int ImpCodeGen::visit(ParenthExp* ep) {
  code << "--- parenthesis---" << endl;
  //ep->e->accept(this);

  return 0;
}

int ImpCodeGen::visit(CondExp* e) {
  /*
  code << "ifexp(";
  e->cond->accept(this);
  code << ",";
  e->etrue->accept(this);
  code << ",";
  e->efalse->accept(this);
  code << ')';
  */
  return 0;
}
