#include "environment.hh"

#include <iostream>

Environment::Environment() {}

void Environment::clear() {
  ribs.clear();
}

void Environment::add_level() {
  unordered_map<string, int> r;
  ribs.push_back(r);
}

void Environment::add_var(string var, int value) {
  ribs.back()[var] = value;
}

void Environment::add_var(string var) {
  ribs.back()[var] = 0;
}

bool Environment::remove_level() {
  if (ribs.size()>0) {
    ribs.pop_back();
    return true;
  }
  return false;
}

/*  *** private **** */

int Environment::search_rib(string var) {
  int idx = ribs.size() - 1;  
  while (idx >= 0) {
    unordered_map<std::string,int>::const_iterator it = ribs[idx].find(var);
    if (it != ribs[idx].end()) // not found
      return idx;
    idx--;    
  }
  return -1;
}

/* *** */

bool Environment::update(string x, int v) {
  int idx = search_rib(x);
  if (idx < 0) return false;
  ribs[idx][x] = v;
  return true;
}

bool Environment::check(string x) {
  int idx = search_rib(x);
  return (idx >= 0);
}

int Environment::lookup(string x) {
  int idx = search_rib(x);
  if (idx < 0) return 0;
  else return ribs[idx][x];
}

bool Environment::lookup(string x, int& v) {
  int idx = search_rib(x);
  if (idx < 0) return false;
  v = ribs[idx][x];
  return true;
}



