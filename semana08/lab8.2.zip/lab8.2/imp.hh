#ifndef IMP
#define IMP

#include <sstream>
#include <iostream>
#include <stdlib.h>
#include <cstring>

#include <list>

using namespace std;

class ImpVisitor;

enum BinaryOp { PLUS, MINUS, MULT, DIV, EXP, LT, LTEQ, EQ};

enum Type { VOID, INT, BOOL };

  
class Exp {
public:
  virtual int accept(ImpVisitor* v) = 0;
  static string binopToString(BinaryOp op);
  virtual ~Exp() = 0;
};

class BinaryExp : public Exp {
public:
  Exp *left, *right;
  BinaryOp op;
  BinaryExp(Exp* l, Exp* r, BinaryOp op);
  int accept(ImpVisitor* v);
  ~BinaryExp();
};

class NumberExp : public Exp {
public:
  int value;
  NumberExp(int v);
  int accept(ImpVisitor* v);
  ~NumberExp();
};

class IdExp : public Exp {
public:
  string id;
  IdExp(string id);
  int accept(ImpVisitor* v);
  ~IdExp();
};

class ParenthExp : public Exp {
public:
  Exp *e;
  ParenthExp(Exp *e);
  int accept(ImpVisitor* v);
  ~ParenthExp();
};

class CondExp : public Exp {
public:
  Exp *cond, *etrue, *efalse;
  CondExp(Exp* c, Exp* et, Exp* ef);
  int accept(ImpVisitor* v);
  ~CondExp();
};



class Stm {
public:
  virtual int accept(ImpVisitor* v) = 0;
  virtual ~Stm() = 0;
};

class StatementList;


class AssignStatement : public Stm {
public:
  string id;
  Exp* rhs;  
  AssignStatement(string id, Exp* e);
  int accept(ImpVisitor* v);
  ~AssignStatement();
};

class PrintStatement : public Stm {
public:
  Exp* e;  
  PrintStatement(Exp* e);
  int accept(ImpVisitor* v);
  ~PrintStatement();
};

class IfStatement : public Stm {
public:
  Exp* cond;
  StatementList *tsl, *fsl;
  IfStatement(Exp* c, StatementList* tsl, StatementList *fsl);
  int accept(ImpVisitor* v);
  ~IfStatement();
};

class WhileStatement : public Stm {
public:
  Exp* cond;
  StatementList *sl;
  WhileStatement(Exp* c, StatementList* sl);
  int accept(ImpVisitor* v);
  ~WhileStatement();
};


class StatementList {
public:
  list<Stm*> slist;
  StatementList();
  void add(Stm* s);
  int accept(ImpVisitor* v);
  ~StatementList();
};


class VarDec {
public:
  string type;
  list<string> vars;
  VarDec(string type, list<string> vars);
  int accept(ImpVisitor* v);
  ~VarDec();
};


class VarDecList {
public:
  list<VarDec*> vdlist;
  VarDecList();
  void add(VarDec* s);
  int accept(ImpVisitor* v);
  ~VarDecList();
};


class Program {
public:
  VarDecList* var_decs;
  StatementList* slist;
  Program(VarDecList* vdl, StatementList* sl);
  int accept(ImpVisitor* v);
  ~Program();
};



#endif

