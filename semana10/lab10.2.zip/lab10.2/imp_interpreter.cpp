#include "imp_interpreter.hh"

int ImpInterpreter::interpret(Program* p) {
  env.clear();
  p->accept(this);
  return 0;
}

// modificar
int ImpInterpreter::visit(Program* p) {
  env.add_level();
  p->var_decs->accept(this);
  p->fun_decs->accept(this);
  // que mas? Como ejecuto main?
  env.remove_level();
  return 0;
}

int ImpInterpreter::visit(Body* b) {
  env.add_level(); 
  b->var_decs->accept(this);
  b->slist->accept(this);
  env.remove_level();  
  return 0;
}

int ImpInterpreter::visit(VarDecList* decs) {
  list<VarDec*>::iterator it;
  for (it = decs->vdlist.begin(); it != decs->vdlist.end(); ++it) {
    (*it)->accept(this);
  }
  return 0;
}

int ImpInterpreter::visit(FunDecList* s) {
  /*
  list<FunDec*>::iterator it;
  for (it = s->fdlist.begin(); it != s->fdlist.end(); ++it) {
    (*it)->accept(this);
  }
  return;
  */
  return 0;
}

int ImpInterpreter::visit(VarDec* vd) {
  list<string>::iterator it;
  for (it = vd->vars.begin(); it != vd->vars.end(); ++it) {
    env.add_var(*it);
  }   
  return 0;
}

int ImpInterpreter::visit(FunDec* fd) {
  /*
  env.add_level();
  ImpType funtype = env.lookup(fd->fname);
  ImpType rtype, ptype;
  rtype.set_basic_type(funtype.types.back());
  list<string>::iterator it;
  int i=0;
  for (it = fd->vars.begin(); it != fd->vars.end(); ++it, i++) {
    ptype.set_basic_type(funtype.types[i]);
    env.add_var(*it,ptype);
  } 
  env.add_var("return", rtype);
  fd->body->accept(this);
  env.remove_level();
  */
  return 0;
}


int ImpInterpreter::visit(StatementList* s) {
  list<Stm*>::iterator it;
  for (it = s->slist.begin(); it != s->slist.end(); ++it) {
    (*it)->accept(this);
  }
  return 0;
}

int ImpInterpreter::visit(AssignStatement* s) {
  int v = s->rhs->accept(this);
  if (!env.check(s->id)) {
    cout << "Variable " << s->id << " undefined" << endl;
    exit(0);
  }
  env.update(s->id, v);  
  return 0;
}

int ImpInterpreter::visit(PrintStatement* s) {
  int v = s->e->accept(this);
  cout << v << endl;
  return 0;
}

int ImpInterpreter::visit(IfStatement* s) {
  if (s->cond->accept(this)) {
    s->tbody->accept(this);
  } else {
    if (s->fbody != NULL)
      s->fbody->accept(this);
  }
  return 0;
}

int ImpInterpreter::visit(WhileStatement* s) {
 while (s->cond->accept(this)) {
    s->body->accept(this);
  }
 return 0;
}

int ImpInterpreter::visit(ReturnStatement* s) {
  /*
  ImpType rtype = env.lookup("return");
  ImpType etype;
  if (s->e != NULL)
    etype = s->e->accept(this);
  else
    etype = voidtype;
  if (!rtype.match(etype)) {
    cout << "Return type mismatch: " << rtype << "<->" << etype << endl;
    exit(0);
  }
  */
  return 0;
}

int ImpInterpreter::visit(BinaryExp* e) {
  int v1 = e->left->accept(this);
  int v2 = e->right->accept(this);
  int result = 0;
  switch(e->op) {
  case PLUS: result = v1+v2; break;
  case MINUS: result = v1-v2; break;
  case MULT: result = v1 * v2; break;
  case DIV: result = v1 / v2; break;
  case EXP:
    result = 1;
    while (v2 > 0) { result *= v1; v2--; }
    break;
  case LT: result = (v1 < v2) ? 1 : 0; break;
  case LTEQ: result = (v1 <= v2) ? 1: 0; break;
  case EQ: result = (v1 == v2) ? 1 : 0; break;
  }
  return result;
}

int ImpInterpreter::visit(NumberExp* e) {
  return e->value;
}

int ImpInterpreter::visit(TrueFalseExp* e) {
  int r = (e->value) ? 1 : 0;
  return r;
}

int ImpInterpreter::visit(IdExp* e) {
  if (env.check(e->id))
    return env.lookup(e->id);
  else {
    cout << "Variable indefinida: " << e->id << endl;
    exit(0);
  }
  return 0;
}

int ImpInterpreter::visit(ParenthExp* ep) {
  return ep->e->accept(this);
}

int ImpInterpreter::visit(CondExp* e) {
  if (e->cond->accept(this) == 0)
    return e->efalse->accept(this);
  else
    return e->etrue->accept(this);
}

int ImpInterpreter::visit(FCallExp* e) {
  return 0;
}
