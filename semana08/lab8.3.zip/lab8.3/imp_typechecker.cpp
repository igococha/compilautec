#include "imp_typechecker.hh"

void ImpTypeChecker::typecheck(Program* p) {
  env.clear();
  p->accept(this);
  return;
}

void ImpTypeChecker::visit(Program* p) {
  p->body->accept(this);
  return;
}

void ImpTypeChecker::visit(Body* b) {
  env.add_level();
  cout << "--start decs---" << endl;
  b->var_decs->accept(this);
  cout << "--end decs---" << endl;
  b->slist->accept(this);
  env.remove_level();  
  return;
}


void ImpTypeChecker::visit(VarDecList* decs) {
  list<VarDec*>::iterator it;
  for (it = decs->vdlist.begin(); it != decs->vdlist.end(); ++it) {
    (*it)->accept(this);
  }  
  return;
}

void ImpTypeChecker::visit(VarDec* vd) {
  list<string>::iterator it;
  for (it = vd->vars.begin(); it != vd->vars.end(); ++it) {
    // env.add_var(*it);
    cout << "vardec " << vd->type << " " << *it << endl;
  }   
  return;
}

void ImpTypeChecker::visit(StatementList* s) {
  list<Stm*>::iterator it;
  for (it = s->slist.begin(); it != s->slist.end(); ++it) {
    (*it)->accept(this);
  }
  return;
}

void ImpTypeChecker::visit(AssignStatement* s) {
  /*
  int v = s->rhs->accept(this);
  if (!env.check(s->id)) {
    cout << "Variable " << s->id << " undefined" << endl;
    exit(0);
  }
  env.update(s->id, v);  
  */
  return;
}

void ImpTypeChecker::visit(PrintStatement* s) {
  /*
  int v = s->e->accept(this);
  cout << v << endl;
  */
  return;
}

void ImpTypeChecker::visit(IfStatement* s) {
  /*
  if (s->cond->accept(this)) {
    s->tbody->accept(this);
  } else {
    if (s->fbody != NULL)
      s->fbody->accept(this);
  }
  */
  return;
}



void ImpTypeChecker::visit(WhileStatement* s) {
  /*
 while (s->cond->accept(this)) {
    s->body->accept(this);
  }
  */
 return;
}

string ImpTypeChecker::visit(BinaryExp* e) {
  /*
  int v1 = e->left->accept(this);
  int v2 = e->right->accept(this);
  int result = 0;
  switch(e->op) {
  case PLUS: result = v1+v2; break;
  case MINUS: result = v1-v2; break;
  case MULT: result = v1 * v2; break;
  case DIV: result = v1 / v2; break;
  case EXP:
    result = 1;
    while (v2 > 0) { result *= v1; v2--; }
    break;
  case LT: result = (v1 < v2) ? 1 : 0; break;
  case LTEQ: result = (v1 <= v2) ? 1: 0; break;
  case EQ: result = (v1 == v2) ? 1 : 0; break;
  }
  */
  return "void";
}

string ImpTypeChecker::visit(NumberExp* e) {
  //return e->value;
  return "void";
}

string ImpTypeChecker::visit(IdExp* e) {
  /*
  if (env.check(e->id))
    return env.lookup(e->id);
  else {
    cout << "Variable indefinida: " << e->id << endl;
    exit(0);
  }
  */
  return "void";

}

string ImpTypeChecker::visit(ParenthExp* ep) {
  return ep->e->accept(this);
}

string ImpTypeChecker::visit(CondExp* e) {
  /*
  if (e->cond->accept(this) == 0)
    return e->efalse->accept(this);
  else
    return e->etrue->accept(this);
  */
  return "void";
}
