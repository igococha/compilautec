#ifndef ENV
#define ENV

#include <unordered_map>
#include <list>
#include <vector>
#include <string>

using namespace std;

class Environment {
private:
  unordered_map<string, int> level;
  vector<unordered_map<string, int> > ribs;
  int search_rib(string);  
public:
  Environment();
  void clear();
  void add_level();
  void add_var(string, int);
  void add_var(string);
  bool remove_level();  
  bool update(string x, int v);
  bool check(string x);
  int  lookup(string x);
  bool lookup(string x, int& v);
};

#endif


