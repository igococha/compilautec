#ifndef ENV
#define ENV

#include <unordered_map>
#include <list>
#include <vector>
#include <string>

#include <iostream>

using namespace std;



class Environment {
private:
  vector<unordered_map<string, int> > ribs;
  int search_rib(string var) {
    int idx = ribs.size() - 1;  
    while (idx >= 0) {
      unordered_map<std::string,int>::const_iterator it = ribs[idx].find(var);
      if (it != ribs[idx].end()) // not found
	return idx;
      idx--;    
    }
    return -1;
}
public:
  Environment() {}
  void clear() {
    ribs.clear();
  }
  void add_level(){
    unordered_map<string, int> r;
    ribs.push_back(r);
  }
  void add_var(string var, int value) {
    ribs.back()[var] = value;
  }
  void add_var(string var) {
    ribs.back()[var] = 0;
  }
  bool remove_level() {
    if (ribs.size()>0) {
      ribs.pop_back();
      return true;
    }
    return false;
  } 
  bool update(string x, int v) {
    int idx = search_rib(x);
    if (idx < 0) return false;
    ribs[idx][x] = v;
    return true;
  }
  bool check(string x) {
    int idx = search_rib(x);
    return (idx >= 0);
  }
  int  lookup(string x) {
    int idx = search_rib(x);
    if (idx < 0) return 0;
    else return ribs[idx][x];
  }
  bool lookup(string x, int& v) {
    int idx = search_rib(x);
    if (idx < 0) return false;
    v = ribs[idx][x];
    return true;
  }

};

#endif


